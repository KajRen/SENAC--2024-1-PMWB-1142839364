let numeros = []

function incNum() {
  const numeroInput = document.getElementById('numero')
  const numero = parseInt(numeroInput.value)

  if (isNaN(numero) || numero < 1 || numero > 100 || numeros.includes(numero)) {
    alert('Inserção inválida (Os números não devem se repetir e devem ser de 1 a 100).')
    return
  }

  numeros.push(numero)
  const selNums = document.getElementById('numeros')
  const option = document.createElement('option')
  option.text = `Valor ${numero} adicionado`
  selNums.add(option)
}
function finali() {
  if (numeros.length === 0) {
    alert('Adicione valores antes de finalizar')
    return
  }

  const maiorVal = Math.max(...numeros)
  const menorVal = Math.min(...numeros)
  const somaVal = numeros.reduce((acc, curr) => acc + curr, 0)
  const mediaVal = somaVal / numeros.length

  const resultado = document.getElementById('resultado')
  resultado.innerHTML = `
    <p>No total há ${numeros.length} elementos cadastrados</p>
    <p>Foi informado como maior valor : ${maiorVal}</p>
    <p>Foi informado como menor valor:${menorVal}</p>
    <p>Somando os valores há:${somaVal}</p>
    <p>A média dos valores informados é ${mediaVal.toFixed(2)}</p>
  `
}