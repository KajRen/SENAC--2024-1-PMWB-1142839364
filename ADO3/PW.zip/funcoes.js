document.getElementById('defIdade').addEventListener('change', function() { updateBackground();
});
document.getElementById('selGenero').addEventListener('change', function() {
    updateBackground();
});

function updateBackground(){
    var idade = parseInt(document.getElementById('defIdade').value);
    var genero = document.getElementById('selGenero').value;   
    var color;
    var imgIda;
    
    if (idade <= 10 && genero == "masculino") {
        color = 'lightblue';
        imgIda = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQmt9fRKqnsr_OhvIWhOuw0Sw8dFVmW2cR_RyNCZEsCpw&s';
    }else if(idade <= 10 && genero == "feminino") {
            color = 'lightpink';
            imgIda = 'https://th.bing.com/th/id/R.3c542a2db99c314dcdece7f8331e7b51?rik=ACrb9qQqfYLdpg&pid=ImgRaw&r=0';
    } else if (idade >= 11 && idade <= 25 && genero == 'masculino') {
        color = 'lightgreen';
        imgIda = 'https://img.freepik.com/fotos-gratis/retrato-de-um-adolescente-sorridente_171337-893.jpg';
    } else if (idade >= 11 && idade <= 25 && genero == 'feminino') {
        color = 'lightred';
        imgIda = 'https://th.bing.com/th/id/OIP.C6g_kNvppMKMBa_9EqUCowHaHa?rs=1&pid=ImgDetMain';
    } else if (idade > 25 && idade < 60 && genero == 'masculino'){
        color = 'green';
        imgIda = 'https://st.depositphotos.com/1743476/2514/i/950/depositphotos_25144791-stock-photo-portrait-of-happy-young-adult.jpg';
    } else if (idade > 25 && idade < 60 && genero == 'feminino'){
        color = 'red';       
        imgIda = 'https://images.freeimages.com/images/premium/previews/2592/25929716-adult-woman.jpg'; 
    } else if (idade >= 60 && idade <= 100 && genero == 'masculino'){
        color = 'blue';
        imgIda = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQhs6x1XVxzQ1yLq_S78LrIhoX4eyNuGbJ0SxeqTe2uFA&s';
    } else if (idade >= 60 && idade <= 100 && genero == 'feminino'){
        color = 'pink';
        imgIda = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTlXp0PqngQjlEumhfhy3Gu0R2Ic7rGIB4g0lkbcjMKTw&s';    
    } else if (idade < 0 || idade > 100){
        window.alert("A idade deve estar entre 0 e 100");
    } else {
        window.alert("O campo de idade deve ser preenchido")
    }

    
    document.body.style.backgroundColor = color;
    var imageElement = document.getElementById('ageImage');
    if (!imageElement) {
        imageElement = document.createElement('img');
        imageElement.id = 'ageImage';
        imageElement.style.width = '800px';
        imageElement.style.display = 'grid';
        imageElement.style.borderStyle = 'double';
        imageElement.style.borderRadius = '800px' ;
        document.body.appendChild(imageElement);
    }
    imageElement.src = imgIda;
}